<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2014-2015 Victor Häggqvist

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => '--------------------
Extra: Parsedown
--------------------
Version: 1.1.0
Created: 2015-03-18
Since: 2014-06-21
Author: Victor Häggqvist <victor@snilius.com>
Source: https://github.com/victorhaggqvist/parsedown-modx
License: MIT
Credits: Emanuil Rusev (https://github.com/erusev) Creator of Parsedown (https://github.com/erusev/parsedown)

This Extra provides a snippet [[Parsedown]] which is a wrapper for Parsedown (https://github.com/erusev/parsedown) packaged for easy use in MODx.

Parsedown (PHP lib) is a parser for Markdown with support for GFM (GitHub Flavored Markdown)

USAGE

[[*content:Parsedown]]
',
    'changelog' => '# 1.1.0
- Parsedown 1.5.1

# 1.0.1
- Bundle actual changelog

# 1.0.0
- Parsedown 1.1.4

# 0.1.0-beta
- Initial release
- Parsedown 1.0.1
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2e736947059529aee2ed0b021326319f',
      'native_key' => 'parsedown',
      'filename' => 'modNamespace/536c26bf5e624c47143cfb1fd333320a.vehicle',
      'namespace' => 'parsedown',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'b5db061e0324c36e794100a0c36c906f',
      'native_key' => 1,
      'filename' => 'modCategory/0720fadef74df8fd422fa3f073cb7a33.vehicle',
      'namespace' => 'parsedown',
    ),
  ),
);