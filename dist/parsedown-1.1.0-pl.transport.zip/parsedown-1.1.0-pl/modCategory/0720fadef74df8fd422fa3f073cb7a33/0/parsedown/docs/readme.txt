--------------------
Extra: Parsedown
--------------------
Version: 1.1.0
Created: 2015-03-18
Since: 2014-06-21
Author: Victor Häggqvist <victor@snilius.com>
Source: https://github.com/victorhaggqvist/parsedown-modx
License: MIT
Credits: Emanuil Rusev (https://github.com/erusev) Creator of Parsedown (https://github.com/erusev/parsedown)

This Extra provides a snippet [[Parsedown]] which is a wrapper for Parsedown (https://github.com/erusev/parsedown) packaged for easy use in MODx.

Parsedown (PHP lib) is a parser for Markdown with support for GFM (GitHub Flavored Markdown)

USAGE

[[*content:Parsedown]]
